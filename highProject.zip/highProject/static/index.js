const productListItems = document.querySelectorAll('div ul li');

// Iteracja po każdym elemencie <li>
productListItems.forEach(listItem => {
    // Pobranie wartości elementu <h3> wewnątrz bieżącego elementu <li>
    const productName = listItem.querySelector('h3').textContent;
    // Pobranie wartości elementu <p> (ceny) wewnątrz bieżącego elementu <li>
    const productPrice = listItem.querySelector('p').textContent;
    // Wyświetlenie wartości w konsoli
    console.log('Nazwa produktu:', productName);
    console.log('Cena:', productPrice);
});

const orderButtons = document.querySelectorAll('.button_order');

// Iteracja po każdym przycisku zamówienia
// orderButtons.forEach(button => {
//     // Nasłuchiwanie zdarzenia kliknięcia na przycisku
//     button.addEventListener('click', function () {
//         // Pobieramy rodzica (wiersz tabeli) przycisku, czyli <tr>
//         const row = this.parentNode.parentNode;
//         // Pobieramy nazwę produktu z pierwszej komórki w danym wierszu
//         const productName = row.cells[0].textContent;
//         // Pobieramy cenę produktu z drugiej komórki w danym wierszu
//         const productPrice = row.cells[1].textContent;
//         // Wyświetlamy nazwę produktu i cenę w konsoli
//         console.log('Nazwa produktu:', productName);
//         console.log('Cena:', productPrice);
//     });
// });

const shoppingList = document.querySelector('.zakupy');

// Iteracja po każdym przycisku zamówienia
orderButtons.forEach(button => {
    // Nasłuchiwanie zdarzenia kliknięcia na przycisku
    button.addEventListener('click', function () {
        // Pobieramy rodzica (wiersz tabeli) przycisku, czyli <tr>
        const row = this.parentNode.parentNode;
        // Pobieramy nazwę produktu z pierwszej komórki w danym wierszu
        const productName = row.cells[0].textContent;
        // Pobieramy cenę produktu z drugiej komórki w danym wierszu
        const productPrice = row.cells[1].textContent;
        // Wyświetlamy nazwę produktu i cenę w konsoli
        console.log('Nazwa produktu:', productName);
        console.log('Cena:', productPrice);

        // Tworzymy nowy element listy <li>
        const listItem = document.createElement('li');
        // Ustawiamy tekst wewnątrz nowego elementu listy
        listItem.textContent = productName + ' - ' + productPrice;
        // Dodajemy nowy element listy do listy zakupów
        shoppingList.appendChild(listItem);
        this.style.backgroundColor = 'green';
    });
});


const sendOrderButton = document.querySelector('.send');

sendOrderButton.addEventListener('click', function () {
    // Znajdź listę zakupów
    const shoppingList = document.querySelector('.zakupy');

    // Pobierz wszystkie elementy listy zakupów
    const shoppingItems = shoppingList.querySelectorAll('li');

    // Tablica, która będzie przechowywać nazwy produktów i ceny
    const orderItems = [];

    // Iteruj przez wszystkie elementy listy zakupów
    shoppingItems.forEach(item => {
        // Pobierz tekst z elementu listy (zawierający nazwę produktu i cenę)
        const itemText = item.textContent;
        // Dodaj tekst do tablicy
        orderItems.push(itemText);
    });

    // Konwertuj tablicę na obiekt JSON
    const jsonOrder = JSON.stringify(orderItems);

    // Wyświetl obiekt JSON w konsoli (do celów demonstracyjnych)
    console.log(jsonOrder);

    // Tutaj możesz przekazać obiekt JSON dalej do backendu lub zapisać w lokalnej zmiennej lub zdarzeniu, według potrzeb
});