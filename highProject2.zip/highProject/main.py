import httpx
from selectolax.parser import HTMLParser

class Product:
    def __init__(self, name, price,category):
        self.name = name
        self.price = price
        self.category = category

url = "https://wolt.com/pl/pol/gdansk/restaurant/lees-chinese"

headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 OPR/108.0.0.0"}

resp = httpx.get(url, headers=headers)
html = HTMLParser(resp.text)

names = html.css("div h3")
prices = html.css("span.sc-de642809-3.hwSkqq")

mainDivs = html.css("div h2")


products = []

headings = ("food", "price","category")

div = html.css("div h2")


bolo = html.body.css(".sc-d15f8f37-1.kTjwHQ")
for p in bolo:

    names = p.css("div h3")
    prices = p.css("span.sc-de642809-3.hwSkqq")
    for name, price, in zip(names, prices):
        product_name = name.text()
        product_price = price.text()
        product_category = p.css_first("div h2").text()
        product = Product(product_name, product_price,product_category)
        products.append(product)
        print(product.name,product.price,product_category)








