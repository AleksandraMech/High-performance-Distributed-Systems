
const orderButtons = document.querySelectorAll('.button_order');

const shoppingList = document.querySelector('.zakupy');

// Iteracja po każdym przycisku zamówienia
orderButtons.forEach(button => {
    // Nasłuchiwanie zdarzenia kliknięcia na przycisku
    button.addEventListener('click', function () {
        // Pobieramy rodzica (wiersz tabeli) przycisku, czyli <tr>
        const row = this.parentNode.parentNode;
        // Pobieramy nazwę produktu z pierwszej komórki w danym wierszu
        const productName = row.cells[0].textContent;
        // Pobieramy cenę produktu z drugiej komórki w danym wierszu
        const productPrice = row.cells[1].textContent;
        // Wyświetlamy nazwę produktu i cenę w konsoli
        console.log('Nazwa produktu:', productName);
        console.log('Cena:', productPrice);

        // Tworzymy nowy element listy <li>
        const listItem = document.createElement('li');
        // Ustawiamy tekst wewnątrz nowego elementu listy
        listItem.textContent = productName + ' - ' + productPrice;
        // Dodajemy nowy element listy do listy zakupów
        shoppingList.appendChild(listItem);
        this.style.backgroundColor = 'green';
    });
});


const sendOrderButton = document.querySelector('.send');

sendOrderButton.addEventListener('click', function () {
    // Znajdź listę zakupów
    const shoppingList = document.querySelector('.zakupy');

    // Pobierz wszystkie elementy listy zakupów
    const shoppingItems = shoppingList.querySelectorAll('li');

    // Tablica, która będzie przechowywać nazwy produktów i ceny
    const orderItems = [];

    // Iteruj przez wszystkie elementy listy zakupów
    shoppingItems.forEach(item => {
        // Pobierz tekst z elementu listy (zawierający nazwę produktu i cenę)
        const itemText = item.textContent;
        // Dodaj tekst do tablicy
        orderItems.push(itemText);
    });

    // Konwertuj tablicę na obiekt JSON
    const jsonOrder = JSON.stringify(orderItems);

    // Wyświetl obiekt JSON w konsoli (do celów demonstracyjnych)
    console.log(jsonOrder);

    // Tutaj możesz przekazać obiekt JSON dalej do backendu lub zapisać w lokalnej zmiennej lub zdarzeniu, według potrzeb
});

const clearButton = document.querySelector('.clear');

clearButton.addEventListener('click', function () {
    // Znajdź listę zakupów
    const shoppingList = document.querySelector('.zakupy');

    // Usuń wszystkie elementy z listy zakupów
    shoppingList.innerHTML = '';

    // Opcjonalnie: wyświetl komunikat potwierdzający w konsoli
    console.log('Lista została wyczyszczona.');

    orderButtons.forEach(button => {
        // Nasłuchiwanie zdarzenia kliknięcia na przycisku
        button.style.backgroundColor = 'white';
    });

    orderButtons.style
});


// Pobierz wszystkie przyciski na stronie
// Utwórz zmienną do śledzenia aktualnego porządku sortowania
var ascendingOrder = true;

// Pobierz wszystkie przyciski na stronie
var buttons = document.getElementsByTagName("button");

// Iteruj przez wszystkie przyciski
for (var i = 0; i < buttons.length; i++) {
    // Sprawdź tekst każdego przycisku
    if (buttons[i].textContent === "Price") {
        // Znaleziono przycisk "Price", możesz wykonać odpowiednie działanie tutaj
        console.log("Znaleziono przycisk Price!");
        // Dodaj obsługę zdarzenia dla tego przycisku
        buttons[i].addEventListener('click', function () {
            // Kod obsługi kliknięcia dla przycisku "Price"
            console.log("Kliknięto przycisk Price!");

            // Pobierz wszystkie wiersze tabeli
            var rows = document.querySelectorAll('table tr');

            // Konwertuj wiersze do tablicy, aby można je było sortować
            var rowsArray = Array.prototype.slice.call(rows, 1); // Zaczynamy od indeksu 1, pomijając nagłówek

            // Zmień porządek sortowania na przeciwny
            ascendingOrder = !ascendingOrder;

            // Posortuj wiersze według ceny
            rowsArray.sort(function (rowA, rowB) {
                var priceA = parseFloat(rowA.children[2].textContent);
                var priceB = parseFloat(rowB.children[2].textContent);
                // Jeśli sortujemy rosnąco, zwróć różnicę priceA - priceB, w przeciwnym razie priceB - priceA
                return ascendingOrder ? priceA - priceB : priceB - priceA;
            });

            // Usuń obecne wiersze z tabeli
            for (var j = 1; j < rows.length; j++) {
                rows[j].remove();
            }

            // Dodaj posortowane wiersze z powrotem do tabeli
            rowsArray.forEach(function (row) {
                document.querySelector('table').appendChild(row);
            });
        });
    }
}

// Pobierz wszystkie pola wyboru kategorii
// Pobierz wszystkie pola wyboru kategorii
var checkboxes = document.querySelectorAll('input[name="categories"]');

// Dodaj obsługę zdarzenia dla każdego pola wyboru
checkboxes.forEach(function (checkbox) {
    checkbox.addEventListener('change', function () {
        // Utwórz tablicę, aby przechowywać wybrane kategorie
        var selectedCategories = [];

        // Iteruj przez wszystkie pola wyboru, aby znaleźć wybrane kategorie
        checkboxes.forEach(function (checkbox) {
            if (checkbox.checked) {
                selectedCategories.push(checkbox.value);
            }
        });

        // Pobierz wszystkie wiersze tabeli z danymi produktów
        var rows = document.querySelectorAll('table tr');

        // Iteruj przez wiersze tabeli, aby pokazać lub ukryć odpowiednie wiersze w zależności od wybranych kategorii
        rows.forEach(function (row) {
            // Sprawdź, czy wiersz jest wierszem danych (pomiń pierwszy wiersz z nagłówkami)
            if (!row.querySelector('th')) {
                // Sprawdź, czy produkt należy do przynajmniej jednej z wybranych kategorii
                var categoryCell = row.querySelector('td:first-child');
                if (categoryCell) {
                    var productCategory = categoryCell.textContent;
                    if (selectedCategories.includes(productCategory)) {
                        // Pokaż wiersz, jeśli produkt należy do przynajmniej jednej z wybranych kategorii
                        row.style.display = '';
                    } else {
                        // Ukryj wiersz, jeśli produkt nie należy do żadnej z wybranych kategorii
                        row.style.display = 'none';
                    }
                }
            }
        });
    });
});